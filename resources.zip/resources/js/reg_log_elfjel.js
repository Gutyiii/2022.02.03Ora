$(function(){

    function bejelenkezes(){}

    function elfJelszo(){}
    
    function regisztracio(){}
  
});