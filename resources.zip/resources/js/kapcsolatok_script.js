$(function(){
    /*
    menű felcsúszás csak
    */
});