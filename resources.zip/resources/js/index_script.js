$(function(){
    $("main").scroll(console.log("szia"));

    function gorgetes(){
        console.log("szia");
        $("main").css("grid-template-areas:","'n n n n n n''h h h h h h''s a a a a a''f f f f f f'");
    }
});

